const responnes = [
    {
        title:"Réponse Prix Fr",
        response:"Bonjour Madame Monsieur, Nous vous remercions du temps que vous nous avez consacré et nous serons heureux de répondre à vos questions.Nous allons nous renseigner sur le prix/ la disponibilité de ce produit dans nos magasins et revenir vers vous dès que possible. Carrefour Market vous remercie pour votre fidélité et vous souhaite une très bonne journée. Cordialement Service Relation Client"
    },
    {
        title:"Réponse Prix Ar",
        response:"السلام عليكم،  نشكركم على وقتكم ويسعدنا الرد على أسئلتكم  سوف نستفسر عن سعر / توفر هذا المنتج في متاجرنا ونعود إليكم في أقرب وقت ممكن. من أجل المزيد من المعلومات، ندعوكم إلى زيارة أقرب متجر كارفور. كارفور ماركت يشكرك على ولائك ويتمنى لك يومًا سعيدًا. تحياتي، قسم علاقات العملاء"
    },
    {
        title:"Réponse Disponibilité Ar",
        response:"السلام عليكم،  نشكركم على وقتكم ويسعدنا الرد على أسئلتكم  سوف نستفسر عن سعر / توفر هذا المنتج في متاجرنا ونعود إليكم في أقرب وقت ممكن. من أجل المزيد من المعلومات، ندعوكم إلى زيارة أقرب متجر كارفور. كارفور ماركت يشكرك على ولائك ويتمنى لك يومًا سعيدًا. تحياتي، قسم علاقات العملاء"
    },
    {
        title:"Réponse Disponibilité Fr",
        response:"Bonjour Madame Monsieur, Nous vous remercions du temps que vous nous avez consacré et nous serons heureux de répondre à vos questions.Nous allons nous renseigner sur le prix/ la disponibilité de ce produit dans nos magasins et revenir vers vous dès que possible. Carrefour Market vous remercie pour votre fidélité et vous souhaite une très bonne journée. Cordialement Service Relation Client"
    },
    {
        title:"Modes de paiement Fr",
        response:"Bonjour Madame Monsieur, Avant toute chose, nous vous remercions du temps que vous nous avez consacré et nous serons heureux de répondre à vos questions. Vous pouvez payer en espèce, par chèque ou par carte bancaire.Nous vous remercions pour votre fidélité et vous souhaitons une très bonne journée, Cordialement Service Relation Client"
    },
    {
        title:"Modes de paiement Ar",
        response:"السلام عليكم  نشكركم على وقتكم ويسعدنا الرد على أسئلتكم  يمكنكم الأداء نقدا أو بالبطاقة البنكية أو بالشيك كارفور ماركت يشكرك على ولائك ويتمنى لك يومًا سعيدًا. تحياتي،مصلحة الزبناء"
    },
    {

        title:"Nom du produit Ar",
        response:"Bonjour Madame Monsieur, Nous vous remercions du temps que vous nous avez consacré et nous serons heureux de répondre à vos questions.Nous allons nous renseigner sur le prix/ la disponibilité de ce produit dans nos magasins et revenir vers vous dès que possible. Carrefour Market vous remercie pour votre fidélité et vous souhaite une très bonne journée. Cordialement Service Relation Client"
    },
    {
        title:"Nom du produit Fr",
        response:"السلام عليكم،  نشكركم على وقتكم ويسعدنا الرد على أسئلتكم  سوف نستفسر عن سعر / توفر هذا المنتج في متاجرنا ونعود إليكم في أقرب وقت ممكن. من أجل المزيد من المعلومات، ندعوكم إلى زيارة أقرب متجر كارفور. كارفور ماركت يشكرك على ولائك ويتمنى لك يومًا سعيدًا. تحياتي، قسم علاقات العملاء"
    },
  
]

require('dotenv').config()
var mysql      = require('mysql');

const connection = module.exports =  mysql.createConnection({
  host     : process.env.HOST,
  user     : process.env.DATABASE_USER,
  password : process.env.DATABASE_PASSWORD,
  database : process.env.DATABASE
});

responnes.forEach(({title,response}) => {

    connection.query("insert into faq (title,content) values (?,?)",[title,response],(err,res) => {
        if(err) console.log(err)

        console.log("Res")
    })


})