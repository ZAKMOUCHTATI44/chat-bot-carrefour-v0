var cors = require('cors')
const express = require('express')
const { listCities } = require('./utils/Cities')
const { storeFilter, groupes, marques, getStores, getStoreById } = require('./utils/StoreFilter')
const { login } = require('./utils/User')
const { authenticateToken } = require('./middlewares/getUser')
const { upload, getCatalogs } = require('./utils/Catalogue')
const { getTickets, showTicket, replyTicket } = require('./utils/Ticket')
const connection = require('./database/Connection')
const app = express()
app.use(express.json())
app.use(express.static('public/upload'));
 
app.use(cors())

app.post('/login',login)

app.get('/cities',listCities)

app.get('/stores',storeFilter)

app.get('/horaires',getStores)

app.get("/store/:id",getStoreById)

app.get('/groupes',groupes)

app.get('/marques',marques)

app.post('/upload',upload)

app.get('/catalogs',getCatalogs)

app.get('/tickets',getTickets)

app.get('/tickets/:ticketId',showTicket)

app.post("/reply-ticket",replyTicket)

app.get("/faq",(req,res) => {
    connection.query("select *from faq",(err,result) => {
        if(err) return res.send([])

        res.send({faq:result})
    })
})
app.get("/faq/:id",(req,res) => {
    let {id} = req.params
    connection.query("select *from faq where id = ?",id,(err,result) => {
        if(err) return res.send([])

        res.send({faq:result[0]})
    })
})

app.post('/add',authenticateToken,(req,res) => {
    res.send("HelloWOlrd")
})

app.listen(4000,()=> {console.log("App Started In Runing !! ")})