const connection = require("../database/Connection");

exports.getUserById = (id) => {
    let req = "select user"
}